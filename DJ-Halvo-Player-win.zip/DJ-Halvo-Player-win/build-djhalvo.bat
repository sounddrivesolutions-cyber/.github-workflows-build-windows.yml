@echo off
REM DJ Halvo Audio Player - build za Windows
cd /d "%~dp0djhalvo-player\src-tauri"
where cargo >nul 2>nul
if errorlevel 1 (
  echo Nema Rust toolchana. Instaliraj sa https://rustup.rs pa ponovo pokreni ovaj fajl.
  pause
  exit /b 1
)
set "PATH=%USERPROFILE%\.cargo\bin;%PATH%"
cargo tauri --version >nul 2>nul
if errorlevel 1 (
  echo Instaliram tauri-cli v2 (samo prvi put, traje par minuta)...
  cargo install tauri-cli --version "^2" --locked
)
if not exist "icons\icon.ico" (
  echo Pravim ikonice (samo prvi put)...
  cd /d "%~dp0djhalvo-player"
  cargo tauri icon src-tauri\icons\icon.png
  cd /d "%~dp0djhalvo-player\src-tauri"
)
echo Gradim DJ Halvo Audio Player (prvi build traje duze)...
cargo tauri build
echo GOTOVO. Installer je u: djhalvo-player\src-tauri\target\release\bundle\nsis\
start "" "target\release\bundle\nsis"
pause
