DJ HALVO AUDIO PLAYER - Windows paket
=======================================

STA TREBA (samo prvi put, na Windows masini):
1. Rust: https://rustup.rs (Download, sve Next-Next)
2. MSVC Build Tools: instaliraj 'Visual Studio Build Tools'
   https://visualstudio.microsoft.com/downloads/ -> 'Build Tools for Visual Studio'
   pri instalaciji ukljuci: 'Desktop development with C++' (treba MSVC + Windows 10/11 SDK)
   WebView2 je vec u Windows 10/11, nista dodatno.

BUILD:
1. Raspakuj ovaj ZIP (npr. C:\DJ-Halvo-Player-win\)
2. Dvoklik na build-djhalvo.bat (prvi build 10-20 min, posle brzo)
3. Installer: djhalvo-player\src-tauri\target\release\bundle\nsis\
   fajl oblika: DJ Halvo Audio Player_1.0.0_x64-setup.exe

NAPOMENE:
- Posle builda instaliraj setup na masinu lokala.
- HW ID procitaj u plejeru (Licenca tab), licencu pravi klijentov generator.
- Baza muzike: Biblioteka -> Ucitaj bazu (folder ili eksterni disk).
- Internet NE treba za svirku (samo je player offline).

OPCIJA B - build bez Windows masine (samo sa MacBooka, besplatno):
1. Napravi besplatan nalog na https://github.com
2. New repository (moze Private), uploaduj CEO sadrzaj ovog ZIP-a u repo
   (Add file -> Upload files, ukljucujuci .github folder)
3. Idi na Actions -> 'Build Windows installer' -> Run workflow -> Run
4. Sacekaj ~15-20 min da se zavrsi (zelena kvačica),
   pa skini installer iz Artifacts na dnu stranice.
5. Taj setup.exe nosis na Windows masinu lokala i instaliras.
   Windows ce upozoriti 'Unknown publisher' (nismo kupili sertifikat ~300$/god) -
   klikni 'More info -> Run anyway'. Isto vazi i za Mac verziju.
